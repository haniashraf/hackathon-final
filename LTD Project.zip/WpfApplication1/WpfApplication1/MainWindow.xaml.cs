﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
        public MainWindow()
        {
            InitializeComponent();


            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }


        int time = 0;
        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {

            // string s = Activefrom.Text; // "22/11/2010  07:00:00 AM";

            time++;

            if (time == 5)
            {
                Map1.Fill = new ImageBrush(new BitmapImage(new Uri("c:\\users\\khalid osama\\documents\\visual studio 2015\\Projects\\WpfApplication1\\WpfApplication1\\map1.png")));
                img2.Visibility = Visibility.Hidden;
            }
            else if (time == 20)
            {
                Map1.Fill = new ImageBrush(new BitmapImage(new Uri("c:\\users\\khalid osama\\documents\\visual studio 2015\\Projects\\WpfApplication1\\WpfApplication1\\map2.png")));

            }
            else if (time == 40)
            {
                Map1.Fill = new ImageBrush(new BitmapImage(new Uri("c:\\users\\khalid osama\\documents\\visual studio 2015\\Projects\\WpfApplication1\\WpfApplication1\\map3.png")));
               // time = 0;
            }
           
            else if (time == 60)
            {

                Map1.Fill = new ImageBrush(new BitmapImage(new Uri("c:\\users\\khalid osama\\documents\\visual studio 2015\\Projects\\WpfApplication1\\WpfApplication1\\map4.png")));

                img2.Visibility = Visibility.Visible;
                L2.Content = "There is a traffic accident - 12 km away";
                L2.Foreground = Brushes.Red;
            }
            else if (time == 80)
            {
                Map1.Fill = new ImageBrush(new BitmapImage(new Uri("c:\\users\\khalid osama\\documents\\visual studio 2015\\Projects\\WpfApplication1\\WpfApplication1\\map5.png")));
                // time = 0;
                img2.Visibility = Visibility.Hidden;
                time = 0;
                L2.Foreground = Brushes.White ;
                L2.Content = "KING ABDUL ALZIZ ROِD";
            }
       


            L1.Content = string.Format("{0:hh:mm:ss tt}", DateTime.Now);
        }
    }
}
